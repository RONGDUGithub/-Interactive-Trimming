
data = rv;
k_range = 2:20;
sse = zeros(1, length(k_range));
for ik = 1:length(k_range)
    rng(1);
    ki = k_range(ik);
    [idx, C, sumd] = kmeans(data, ki,'MaxIter', 500);
    sse(ik) = sum(sumd);
end

slope = diff(sse);
slope2 = diff(slope);
slope2 = [slope2(1), slope2];
 elbow = find(slope2 < mean(slope2), 1, 'first') + 1;
