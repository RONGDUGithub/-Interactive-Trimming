%非纳什均衡
clear all;
index=1;

control=dlmread('control.txt');
control_label=dlmread('control_label.txt');
A_1=cat(2,control,control_label);

SSE=[];
%选择数据
%rv=data2;
rv=A_1;

elbow_function;
[Idx1,Cori1,sumD1,D1]=kmeans(rv,elbow,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
sumDori=sum(sumD1);

trim_switch=1;


p=0.1;
%选择数据
a=rv;
%攻击者比例
attack_ratio=0.2;
round_no=25;
data_generate
elbow=10;
round_time=1;
MSE_final=zeros(round_time,2);
%cluster_number=4;
nmi_final=zeros(round_time,2);
sumd_final=zeros(round_time,2);
final_attack_rati0_gang=zeros(1,round_time);
final_attack_ratio_elastic=zeros(1,round_time);

for round=1:round_time
    MD1=[];

  sumD=[];
  %方案1
  baseline_evade_gang;
    H=size(report_vector_copy);
h1=H(1);  
  final_attack_rati0_gang(1,round)=length(find(report_vector_copy_gang(:,end)==-1))/h1;
%   MD1=[MD1,mean_distance];
%   sumD=[sumD,sumD2];
%   base_ostrich1=Idx1;
%   base_ostrich2=Idx2;


  %方案2
  baseline_evade_elastic;
  H=size(report_vector_copy);
h1=H(1);  
    final_attack_rati0_elastic(1,round)=length(find(report_vector_copy_elastic(:,end)==-1))/h1;
%   MD1=[MD1,mean_distance];
% 
%   sumD=[sumD,sumD2];
%   base_idx1=Idx1;
%   base_idx2=Idx2;
% 
%   MD1_final(round,:)=MD1;
end
final_ratio_gang=mean(final_attack_rati0_gang)
final_ratio_elastic=mean(final_attack_rati0_elastic)
% if round_time==1
% % 真质心和假质心的距离，按照4种方案
% a_mean_distance=(MD1_final);
% %nmi的最后指标，按照4种方案
% sumd_final=sumD;
% else
% a_mean_distance=mean(MD1_final);
% %nmi的最后指标，按照4种方案
% sumd_final=mean(sumD);
% end
% 
% bar_figure2;
%将结果存储
save test1
%load handel
%sound(y,Fs)