% 导入测试数据集
test_data = Test_data';
height = test_data(:, 1);
weight = test_data(:, 2);

% 给身高数据添加常数项
height = [ones(length(height), 1), height];

% 加载训练好的参数
% 计算预测值并计算均方误差
y_pred = height * theta;
mse = sum((y_pred - weight).^2) / length(weight);
%fprintf('MSE = %f\n', mse);