clear all;
load('data_taxi.mat')
index=2;
attack_ratio=0;
round_time=1;
round_no=20;
epsilon_list = linspace(0.5, 5, 10);
%MD1_final = zeros(round_time, 6, length(epsilon_list));
MD1_final=zeros(length(epsilon_list),4);
for ih = 1:length(epsilon_list)
    epsilon = epsilon_list(ih);
    x1=0.95; 
    x2=x1+0.01;
    x3=x1-0.03;

    MD2=zeros(round_time,4);
    data_generate_input;
    
    for round = 1:round_time
        MD1=[];
        % 方案0
%        Ostrich;
%        mean_sta;
%        MD1=[MD1,meann];

        % 方案1
%        baseline;
%        mean_sta;
%        MD1=[MD1,meann];

        % 方案2
        tit_for_tat;
        mean_sta;
        MD1=[MD1,meann];

        % 方案3
        k=0.1;
        elastic;
        mean_sta;
        MD1=[MD1,meann];

        % 方案4
        k=0.5;
        elastic;
        mean_sta;
        MD1=[MD1,meann];

        % input attack
        data_generate4;
        MD1=[MD1,mean_x_emf];

        MD2(round,:)=MD1;
    end
    
    % 总计
    MD1_final(ih,:)=MD2;
end

a_mean_distance=MD1_final;
a_mean_final_square=power(a_mean_distance-mean_groundtruth,2);
figure
plot(epsilon_list, a_mean_final_square(:,1), '-o', 'LineWidth', 2)
hold on
plot(epsilon_list, a_mean_final_square(:,2), '-*', 'LineWidth', 2)
plot(epsilon_list, a_mean_final_square(:,3), '-^', 'LineWidth', 2)
plot(epsilon_list, a_mean_final_square(:,4), '-+', 'LineWidth', 2)
%plot(epsilon_list, a_mean_final_square(:,5), '-x', 'LineWidth', 2)
%plot(epsilon_list, a_mean_final_square(:,6), '-s', 'LineWidth', 2)

xticks(epsilon_list)
xlabel('\epsilon')
ylabel('Mean Square Error')
legend('Titfortat', 'Elastic_{0.1}', 'Elastic_{0.5}','EMF')
grid on