%�趨ֻ��һ��������������
function x_remf=REMF(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,ratio,C)
%data_original
%attacker_range_uniform_simple
at_remf=zeros(1,7);
for loop=1:1
%�趨ֻ��һ��������������
%db1=floor(power(user_number,1/2));
n=data_u_map;
M2=eye(db1);
 t=t_pm;
 M4=M2(:,db1-t+1:db1);
M=[M0,M4];
d=number_d2;
x_record=zeros(m_step,d+t);
x=zeros(d+t,1)+1/(d+t);
P=zeros(1,d+t);
for iteration = 1:m_step
    %E
        parfor i=1:d+t
            temp0=0;
            for j=1:db1 
                   mxk=0;
                mxk=sum(M(j,1:d+t)*x);  %���û�취��
                temp0=temp0+n(j)*M(j,i)/(mxk);
            end
             P(i)=x(i)*temp0;
        end
    %��ߵ������Ȼ����ô��� 
    %M 
           temp2(1:d)=P(1:d)/sum(P(1:d));
            x(1:d)=temp2(1:d)*(1-ratio);
           
           temp2(d+1:d+t)=P(d+1:d+t)/sum(P(d+1:d+t));
            x(d+1:d+t)=temp2(d+1:d+t)*ratio;
      
             x_record(iteration,:)=x';

  
       if iteration>2
     h=abs(x_record(iteration-1,:)-x');
     h=sum(h);
     if h<0.0001*exp(epsilon)   %10^-3*exp(epsilon)
         break;
     end
       end
end
x_remf=x;
distribution_discrete_EM33;
end

end
