function nmi_score = calculate_nmi(true_labels, pred_labels)
% 计算聚类结果的 NMI 值
% true_labels: 真实标签，长度为 n 的向量
% pred_labels: 聚类结果，长度为 n 的向量
% nmi_score: 返回值，NMI 值

% 确保 true_labels 和 pred_labels 长度相等
if length(true_labels) ~= length(pred_labels)
    error('标签长度不一致');
end

% 计算熵和互信息
n = length(true_labels);
true_label_counts = histcounts(true_labels, 1:n+1);
pred_label_counts = histcounts(pred_labels, 1:n+1);
joint_label_counts = full(sparse(true_labels, pred_labels, 1));
entropy_true = -sum((true_label_counts/n) .* log2(true_label_counts/n + (true_label_counts==0)));
entropy_pred = -sum((pred_label_counts/n) .* log2(pred_label_counts/n + (pred_label_counts==0)));
entropy_joint = -sum(sum((joint_label_counts/n) .* log2(joint_label_counts/n + (joint_label_counts==0))));
mutual_info = entropy_true + entropy_pred - entropy_joint;

% 计算归一化互信息
if entropy_true == 0 || entropy_pred == 0
    nmi_score = 1;
else
    nmi_score = mutual_info / sqrt(entropy_true * entropy_pred);
end
end