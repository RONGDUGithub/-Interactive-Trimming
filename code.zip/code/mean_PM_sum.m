%要返回一个初始数据，一个Ostrich，还有一个trimming其实就是O'
mean_user_value=mean(A);
% %扰动后的数据的均值 
% mean_PM=mean(user_value_noise_pm1);
%ostrich
mean_ostrich=mean(collect_data);
% trimming后的结果
mean_sort=sort(collect_data);

