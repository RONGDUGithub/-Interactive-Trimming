ws_EM_PM=mean(abs(A'-x_em(1:d)/sum(x_em(1:d))));
ws_EMF_PM=mean(abs(A'-x_emf(1:d)/sum(x_emf(1:d))));
ws_REMF_PM=mean(abs(A'-x_remf(1:d)/sum(x_remf(1:d))));
ws_EM_SW=mean(abs(B'-x_em_sw(1:d_sw)/sum(x_em_sw(1:d_sw))));
ws_EMF_SW=mean(abs(B'-x_emf_sw(1:d_sw)/sum(x_emf_sw(1:d_sw))));
ws_REMF_SW=mean(abs(B'-x_remf_sw(1:d_sw)/sum(x_remf_sw(1:d_sw))));

ws_answer=[ws_EM_PM,ws_EMF_PM,ws_REMF_PM,ws_EM_SW,ws_EMF_SW,ws_REMF_SW];
temp00(ik,:)=ws_answer;