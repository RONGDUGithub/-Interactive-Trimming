function distance = compare_cluster_centers_dist(cdist1, cdist2)
%    计算两个聚类结果的质心距离。
%

% 输入：
% cdist1：第一个聚类结果的质心距离矩阵，一个二维数组，其中 cdist1(i,j) 表示第 i 个聚类的质心和第 j 个聚类的质心之间的距离。
% cdist2：第二个聚类结果的质心距离矩阵，与 cdist1 结构相同。
%
% 输出：·····+···8/    ·   ·   ·······
% 质心距离的平均值。

    % 计算质心距离
    distances = [];
    for i = 1:size(cdist1, 1)
        for j = 1:size(cdist1, 2)
            distance = abs(cdist1(i, j) - cdist2(i, j));
            distances = [distances, distance];
        end
    end

    % 返回质心距离的平均值
    distance = min(distances);
end