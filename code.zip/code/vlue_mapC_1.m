function [l0,r0]=vlue_mapC_1(item,C,data_u,db,number_d) 
l=((C+1)*item)/2-(C-1)/2;
r=l+C-1;
l0=item_location(l,data_u,db);
%r0=l0+number_d-1;
r0=item_location(r,data_u,db);
if item==-1
    l0=1;
    r0=l0+number_d-1;
end
end
%