%均衡的代码 请打开 list_equilibrium
%非均衡大代码，请打开 list_not_equilibrium
%扰动的算法，直接加噪音 list_LDP_direct
%扰动的算法，插入攻击 list_LDP_input

%k_means非随机结果，打开 k_means_test中的 注释掉两个   rng(1);  
control=dlmread('control.txt');
control_label=dlmread('control_label.txt');
A_1=cat(2,control,control_label);

SSE=[];
%选择数据
%rv=data2;
rv=A_1;