% function offset = compute_centroid_offset(Cori1, Cori2)
% % 计算两个聚类结果的质心相对于第一个聚类结果的偏移量
% 
% % 计算第一个聚类结果的质心
% centroid1 = mean(Cori1);
% 
% % 计算第二个聚类结果的质心
% centroid2 = mean(Cori2);
% 
% % 计算质心之间的欧几里德距离
% offset = pdist2(centroid1, centroid2);
% 
% end

function min_offset = compute_centroid_offset(Cori1, Cori2)
% 计算两个聚类结果的质心相对于第一个聚类结果的偏移量

% 计算所有可能的分类对应关系
num_clusters = size(Cori1, 1);
perm = perms(1:num_clusters);

% 计算偏移量
offsets = zeros(size(perm, 1), 1);
for i = 1:size(perm, 1)
    % 按照当前的分类对应关系将 Cori2 与 Cori1 对齐
    aligned_Cori2 = Cori2(perm(i, :), :);

    % 计算偏移量
    offsets(i) = norm(mean(Cori1) - mean(aligned_Cori2));
end

% 返回最小的偏移量
min_offset = min(offsets);

end