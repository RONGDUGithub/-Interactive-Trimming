function plot_kmeans(data, k)
% PLOT_KMEANS 将 K-means 聚类的结果画出来
% 输入：
%   data：需要聚类的数据，大小为 N-by-D，其中 N 是数据点的数量，D 是特征的数量
%   k：聚类的数量
% 输出：
%   无

% 将数据聚类成 k 个簇
[idx, centers] = kmeans(data, k);

% 将数据降到二维
coeff = pca(data);
data_2d = data * coeff(:, 1:2);

% 将聚类中心画成红色的叉号
hold on
scatter(data_2d(:, 1), data_2d(:, 2), 50, 'o', 'MarkerEdgeColor', 'b', 'LineWidth', 1.5);
scatter(centers(:, 1) * coeff(1, 1) + centers(:, 2) * coeff(2, 1), ...
        centers(:, 1) * coeff(1, 2) + centers(:, 2) * coeff(2, 2), ...
        100, 'rx', 'LineWidth', 2);
hold off

% 设置图像属性
title('K-means Clustering');
xlabel('PC 1');
ylabel('PC 2');
legend('Data Points', 'Cluster Centers');
end