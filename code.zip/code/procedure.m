  vec =  eval(['A',num2str(i)]);
  %sorted_vec = sort(vec);
  sorted_vec = sortrows(vec', 2)';
  sorted_vec_temp = sorted_vec';
  sorted_vec_height = sorted_vec_temp(:,2);
  sorted_vec_weight = sorted_vec_temp(:,1);
  max_weight = max(sorted_vec_weight);
  min_weight = min(sorted_vec_weight);

  report_vector_triming = sorted_vec_temp(1:L-ceil((1-p_trim)*L)+1,:);
  % 
  idx = ceil(ai * L);
  attack_height_value = sorted_vec_temp(idx,2);
  attack_height=zeros(1,attack_number) + attack_height;
  attack_weight = min_weight + (max_weight - min_weight) * rand(1, attack_number);
  
  t1=sorted_vec_height';
  t2=sorted_vec_weight';
  trim_temp=[t1, attack_height];
  attack_temp=[t2, attack_weight];
  t3= [trim_temp; attack_temp];
  report_vector = [report_vector, t3];