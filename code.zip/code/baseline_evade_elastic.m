%trim的位置
%p=0.8;
delta=0.05;
x2 = 0.95;
x3 = 0.9;
report_vector = [];
report_vector_copy = [];
b1_copy=[b1,tempH];
%攻击者进攻的位置，这里只是一个起始为主
ai=1;
count=1;
flag1=0;
flag2=0;
x3_count=0;
x2_count=0;
count_ratio=0;

 m=0;
 attack_number_elastic=0;
for ia=1:round_no
     p_trim=0.9*m+0.95*(1-m);
    r = rand();
    if r<p
        ai=x2;
        x2_count=x2_count+attack_number_round;
    else
        ai=x3;
        x3_count=x3_count+attack_number_round;
    end
    m=x2_count/(x2_count+x3_count);
     procedure6;
end
%metric_compare


report_vector_copy_elastic=report_vector_copy;





