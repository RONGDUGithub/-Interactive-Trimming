user_value_noise_pm1
interval0=(2*C)/db;
tk[0]=-C;
for jkl=1:1:db
 tk[jkl]=-C+interval0;
end