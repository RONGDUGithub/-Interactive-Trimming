%rng(1);  
[Idx2,C2,sumD2,D2]=kmeans(report_vector,elbow,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
%mean_distance=compare_cluster_centers_dist(Cori1,C2);
mean_distance=compute_centroid_offset(Cori1,C2);

% ground_index=temp;
% 
% [mean_distance,Idx_all,Idx_part,sumD1,sumD2]=k_means_test(ground_truth_vector,report_vector,elbow,Cori);
% %trimming
% b1_copy=[b1_copy,Idx_all];
% 
% 
% %score_groundtruth = silhouette_score(ground_truth_vector, Idx_all);
% 
% report_vector_copy=[report_vector_copy,Idx_part];
% %report_vector_copy=[report_vector,Idx_part];
% report_vector_copy(:, size_a2+1) == -1; % 找到第一列中等于-1的元素
% report_vector_copy(report_vector_copy(:, size_a2+1) == -1, :) = [] ;% 删除第一列中等于-1的行
% 
% report_vector_part=report_vector_copy(:,size_a2+1);
% Idx2=report_vector_copy(:,size_a2+2);
% 
% A=b1_copy;
% B=report_vector_part;
% % 筛选出B向量中存在的数据
% A_filtered = A(ismember(A(:, size_a2+1), B), :); % 筛选第20列中存在于B向量中的行
% 
% % 按照B向量的顺序进行排序
% idx = ismember(A_filtered(:, size_a2+1), B); % 找到A_filtered中第20列中元素在B向量中的索引
% A_sorted = A_filtered(idx, :); % 按照B向量的顺序排序
% Idx1=A_sorted(:,size_a2+2);
% 
% NMI=nmi_function(Idx1,Idx2);
% 
