function [mean_distance,Idx1,Idx2,sumd1,sumd2]=k_means_test(data1,data2,cluster_number,Cori) 
%train

rng(1);  
[Idx1,C1,sumD1,D]=kmeans(data1,cluster_number,'dist','sqEuclidean','rep',10, 'MaxIter', 200);

rng(1);  
[Idx2,C2,sumD2,D]=kmeans(data2,cluster_number,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
%指标1.  质心距离？但是怎么确定 哪个对哪个
mean_distance=C_distance(Cori,C2);

%mean_distance = silhouette_score(data2, Idx2);


%指标2.  分类准确性，这个需要一个指标，就是同一个分类就加一分，不是就不加，最好找一个官方指标
%NMI=nmi_function(Idx1,Idx2)
%nmi的指标暂时不能用
sumd1=sum(sumD1);;
sumd2=sum(sumD2);;
end
