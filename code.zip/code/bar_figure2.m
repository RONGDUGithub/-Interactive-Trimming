
figure
subplot(2, 1, 1) % 将画布分成2行1列，在第1个子区域内绘制图形
bar((a_mean_distance));
max_al=max(a_mean_distance);
min_al=min((a_mean_distance));
delta1=max_al-min_al;
ylim([min_al-delta1,max_al+delta1 ]);
xticklabels({ 'titfortat', 'elastic'});
title('Distance')

subplot(2, 1, 2) % 将画布分成2行1列，在第2个子区域内绘制图形
bar(sumd_final)
xticklabels({ 'titfortat', 'elastic'});
title('SSE')

 set(gcf, 'PaperPosition', [0.25 0 13.5 10]);
 set(gcf, 'PaperSize', [13 10]); %Ke5p the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
grid off;
%改图名字
saveas(gcf, 'f1_A.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf
