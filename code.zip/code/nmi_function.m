function NMI=nmi_function(G1,G2)
% 假设我们有以下两组分类结果
G1 = [1, 1, 2, 2, 3, 3];
 G2 = [1, 1, 3, 3, 2, 2];

% 计算混淆矩阵
C = confusionmat(G1, G2);

% 转换混淆矩阵为概率矩阵
P = C / sum(C(:));

% 计算 NMI
ni = sum(P, 2);
nj = sum(P, 1);

% 计算互信息 (MI)
MI = sum(sum(P.*(log2(P + (P==0)) - log2(ni * nj + (ni * nj == 0)))));

% 计算熵 (Entropy)
H1 = -sum(ni.*log2(ni + (ni==0)));
H2 = -sum(nj.*log2(nj + (nj==0)));

% 计算 Normalized Mutual Information (NMI)
NMI = 2 * MI / (H1 + H2);
end
