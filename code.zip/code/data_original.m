dbstop if error;

m_step =50;  %限定条件是10次,这个是parfor算法可以多一点
Ht=size(user_value);
user_number=Ht(2);
ep=exp(epsilon);
C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
ratio=0.25;
user_value(randperm(user_number)) = user_value(1:1:user_number);
group_number=user_number;
group_value=user_value;

db1=1000;
Hj=zeros(1,db1);
for k=1:100
user_value_noise_pm1=pmmechnism(group_value,epsilon,group_number);
Hj=Hj+interval1(user_value_noise_pm1,db1,C);
end
hk0=Hj/100;


attacker_range_uniform_simple
PM_platform