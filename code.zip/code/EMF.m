function x_emf=EMF(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,C)

for loop=1:1
 n=data_u_map;
 M2=eye(db1);
 d=number_d2;
 %M4=M2(:,db1-b1+1:db1);
 %M4=M2(:,1:db1-b1);
 %̽�����ǰ������Ǻ���
 t=t_pm;
 M4=M2(:,db1-t+1:db1);
 M=[M0,M4];
x=zeros(d+t,1)+1/(d+t);
P=zeros(1,d+t);
x_record=zeros(m_step,d+t);
h=zeros();
for iteration = 1:m_step
       parfor i=1:d+t
            temp0=0;
            for j=1:db1 
                mxk=sum(M(j,1:d+t)*x);  %���û�취��
                temp0=temp0+n(j).*M(j,i)/(mxk);
            end
             P(i)=x(i)*temp0; 
       end
  x=P/sum(P);
  x_record(iteration,:)=x;
  x=x';   
       if iteration>2
     h=abs(x_record(iteration-1,:)-x');
     h=sum(h);
     if h<0.0001*exp(epsilon)   %10^-3*exp(epsilon)
         h-0.0001*exp(epsilon)        
         break;
     end
       end
end
x_emf=x;
%distribution_discrete_EM33;
end
end


