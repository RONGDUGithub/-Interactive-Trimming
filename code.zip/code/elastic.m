%

% trim_switch=1;
report_vector=[];
report_vector_copy = [];
b1_copy=[b1,tempH];

ai_initial=x1;
p_trim_initial = x1;

for ia=1:round_no
  if ia==1
  ai=ai_initial+0.01;
  %ai=x3+k(t_{i-1}-x1)
  p_trim = p_trim_initial;
  % x1+k(a_{i-1}-x2)
  else
  temp=ai;
  ai=x3+k*(p_trim-x1);
  p_trim = x1+k*(temp-x2);
  end
     if index==1
        procedure2
    else
        if index==2
            procedure4
        end
    end
end
% rng('shuffle');
% rv1=report_vector;
% n = size(rv1, 1);
% idx = randperm(n);
% report_vector = rv1(idx, :);