function mean_distance=C_distance(A1,A2)
% 假设我们有以下两组质心
%A1 = [1, 2, 3; 4, 5, 6; 7, 8, 9];  % A1 是一个 3x3 的矩阵，表示有三个质心，每个质心有三个维度
%A2 = [10, 11, 12; 13, 14, 15; 16, 17, 18];  % A2 也是一个 3x3 的矩阵

% 初始化一个矩阵来保存所有的距离
distances = zeros(size(A1, 1), size(A2, 1));

% 计算 A1 和 A2 的每一对质心的欧几里得距离
for i = 1:size(A1, 1)
    for j = 1:size(A2, 1)
        distances(i, j) = norm(A1(i, :) - A2(j, :));
    end
end

% 计算所有质心之间距离的平均值，作为两组质心的总体距离
mean_distance = mean(distances(:));
end
