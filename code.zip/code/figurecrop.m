% 指定文件夹路径
folder_path = '\figures';

% 列出文件夹下的所有 .fig 文件
fig_files = dir(fullfile(folder_path, '*.fig'));

% 循环处理每个 .fig 文件
for i = 1:numel(fig_files)
    % 读取 .fig 文件
    fig = openfig(fullfile(folder_path, fig_files(i).name));

    % 创建一个新的图形对象
    new_fig = figure('Units', 'points', 'Position', get(fig, 'Position'));

    % 将原始的 .fig 文件中的所有元素复制到新的图形对象中
    copyobj(allchild(fig), new_fig);

    % 设置新图形的边距为零
    new_fig.PaperPositionMode = 'auto';
    new_fig.PaperUnits = 'points';
    position = get(fig, 'Position');
    new_fig.PaperSize = [position(3), position(4)];
    new_fig.Renderer = 'Painters';

    % 导出图形为 PDF 文件
    [~, file_name, ~] = fileparts(fig_files(i).name);
    pdf_file_name = fullfile(folder_path, [file_name '.pdf']);
    exportgraphics(new_fig, pdf_file_name, 'ContentType', 'vector');

    % 关闭图形
    close(new_fig);
end


% % 指定文件夹路径
% folder_path = 'C:\Users\fuyue\Desktop\k_means_elbow\code\figures';
% 
% % 切换到指定文件夹
% cd(folder_path);
% 
% % 读取 .fig 文件
% 
% figure_name = 'Baseline_09'
% fig = openfig('Baseline_09.fig');
% 
% % 创建一个新的图形对象
% newFig = figure('Units', 'points', 'Position', get(fig, 'Position'));
% 
% % 将原始的 .fig 文件中的所有元素复制到新的图形对象中
% copyobj(allchild(fig), newFig);
% 
% % 设置新图形的边距为零
% newFig.PaperPositionMode = 'auto';
% newFig.PaperUnits = 'points';
% position = get(fig, 'Position');
% newFig.PaperSize = [position(3), position(4)];
% newFig.Renderer = 'Painters';
% 
% % 导出图形为 PDF 文件
% exportgraphics(newFig, 'figure_name.pdf', 'ContentType', 'vector');

