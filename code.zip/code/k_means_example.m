%groud_truth 测试

data1= [5.0 3.5 1.3 0.3 -1;
5.5 2.6 4.4 1.2 0;
6.7 3.1 5.6 2.4 1;
5.0 3.3 1.4 0.2 -1;
5.9 3.0 5.1 1.8 1;
5.8 2.6 4.0 1.2 0];
cluster_number=3;
%train
[Idx1,C1,sumD,D]=kmeans(data1,cluster_number,'dist','sqEuclidean','rep',4);

%有毒数据的测试
data2= [5.0 3.5 1.3 0.3 -1;
5.5 2.6 4.4 1.2 0;
6.2 3.1 5.6 2.4 1;
5.1 3.3 1.4 0.2 -1;
5.2 3.0 5.1 1.8 1;
5.2 2.6 4.1 1.2 0];

%train
[Idx2,C2,sumD,D]=kmeans(data2,cluster_number,'dist','sqEuclidean','rep',4);


%指标1.  质心距离？但是怎么确定 哪个对哪个
mean_distance=C_distance(C1,C2)
%指标2.  分类准确性，这个需要一个指标，就是同一个分类就加一分，不是就不加，最好找一个官方指标
NMI=nmi_function(Idx1,Idx2)
