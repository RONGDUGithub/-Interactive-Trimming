function M=Mmatrix_PM(epsilon,db,number_d,serial_it,C,data_u,number_d2)
p0=exp(epsilon/2)/(exp(epsilon/2)+1);
q0=1-p0;
l=zeros();
r=zeros();
for i=1:number_d2
    item=serial_it(i);
    [l0,r0]=vlue_mapC_1(data_u(item),C,data_u,db,number_d);
   t(i)=r0-l0+1;
    l(i)=l0;
    r(i)=r0;
end

M=zeros(db,number_d2);

for j=1:number_d2   
    for i=1:db
    if  i>=l(j)&&i<=r(j)
        M(i,j)=p0/t(j);
    else
        M(i,j)=q0/(db-t(j));
    end
    end
      %sum(M(:,j))
end
end