function result = isSameArrayShuffled(A, B)
% 判断两个数组是否是同一个数组打乱行顺序

% 判断两个数组的维度是否相同
if size(A) ~= size(B)
    result = false;
else
    % 将A和B按行排序
    sortedA = sortrows(A);
    sortedB = sortrows(B);
    
    % 判断排序后的A和B是否相等
    result = isequal(sortedA, sortedB);
end
end