epsilon=1;
%epsilon=1;

data_original_SW;
%C quan  D 3/4C-C  A 0-C/2  B C/2-C
range_p0=floor(db_sw/4);  %C/2 
a11=range_max-1*range_p0;
b11=range_max-0*range_p0;
attacker_range_uniform_SW2;

mean_SW_sum
x_emf_sw=EMF_SW(d_sw,db_sw,t_sw,M,m_step,n_sw);
x_remf_sw=REMF_SW(d_sw,db_sw,t_sw,M,m_step,n_sw,ratio);
%确认一下参数有没有问题
x_cremf_sw=CEMF_SW(db_sw,t_sw,M,n_sw,d_sw,m_step,ratio,x_remf_sw,C);
%写均值
mean_emf_sw=mean_SW1(db_sw,d_sw,x_emf_sw,t_sw,mean_ostriich_sw,b_value);
mean_remf_sw=mean_SW1(db_sw,d_sw,x_remf_sw,t_sw,mean_ostriich_sw,b_value);
mean_cremf_sw=mean_SW1(db_sw,d_sw,x_cremf_sw,t_sw,mean_ostriich_sw,b_value);

% mean_emf_sw=mean_SW(db_sw,x_emf_sw);
% mean_remf_sw=mean_SW(db_sw,x_remf_sw);
% mean_cremf_sw=mean_SW(db_sw,x_cremf_sw);


at_sw=[mean_user_value;mean_ostriich_sw;mean_trimming;mean_emf_sw;mean_remf_sw;mean_cremf_sw];
P2=vpa(at_sw')
hello=0;
