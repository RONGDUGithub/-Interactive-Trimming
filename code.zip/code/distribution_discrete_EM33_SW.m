ydata=zeros();
ydata2=zeros();

ydata = x(1:d_sw);
ydata2= x(d_sw+1:d_sw+t1);
x0=0:1/(d_sw-1):1;
 figure('color',[1 1 1]);
 subplot(2,2,1);
 bar(x0,ydata);
xlabel('Value');
ylabel('Frequency distribution histogram');
x2=-1:3/(t1-1):2;
 subplot(2,2,2);
 bar(x2,ydata2);
format short;
ydata_show=[sum(ydata),sum(ydata2)]


