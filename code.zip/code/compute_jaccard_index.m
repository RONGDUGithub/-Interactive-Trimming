function jaccard_index = compute_jaccard_index(truth_labels, cluster_labels)
% 计算聚类结果和真实分类之间的 Jaccard Index

n_samples = numel(truth_labels);
n_clusters = numel(unique(cluster_labels));
match_mat = zeros(n_clusters, n_samples);
for i = 1:n_clusters
    c_idx = (cluster_labels == i);
    for j = 1:n_samples
        match_mat(i, j) = sum(truth_labels(j) == truth_labels(c_idx));
    end
end

[~, match_idx] = munkres(-match_mat);

n_correct = 0;
n_union = 0;
for i = 1:n_samples
    if match_idx(cluster_labels(i)) == truth_labels(i)
        n_correct = n_correct + 1;
    end
    if match_mat(cluster_labels(i), truth_labels(i)) == 0
        n_union = n_union + 1;
    end
end
jaccard_index = n_correct / (n_samples - n_union);

end