%
%A=A(1:1000);
n = length(A);
idx = randperm(n);
A_shuffled = A(idx);

%设置参数


La=length(A);

%生成扰动数据ep=exp(epsilon);
ep=exp(epsilon);
C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
db1=1000;

%user_value_noise_pm1=pmmechnism(A_shuffled,epsilon,La);

b=A_shuffled;

pick=1;

attack_number=floor(La/(1-attack_ratio)*attack_ratio);
attack_number_round=floor(attack_number/round_no);
attack_number_all=attack_number_round*round_no;


La0=La-attack_number_all;
La1=La0-mod(La,round_no);
La_round=La1/round_no;

b1=b(1:La1,:);
mean_groundtruth=mean(b1);
ground_truth_vector=b1;
temp=1:La1;
tempH=temp';
all_index=tempH;
b1_copy=[b1,tempH];

b_attack=zeros(attack_number_all,1);

attacke_default_matrix =b_attack;

%确定肘部法k的结果
%elbow_function;
