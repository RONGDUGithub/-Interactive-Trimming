%设置参数
attack_ratio=0.2;
round_no=20;
La=length(A);

%生成扰动数据ep=exp(epsilon);
ep=exp(epsilon);
C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
db1=1000;
%Hj=zeros(1,La1);

attack_value=0.99*2*C-C;
A_attack=zeros(attack_number_all,1)+attack_value;
A_collect=[A_shuffled;A_attack];



db1=1000;
data_u_map=interval1(A_collect,db1,C);

O_pie=mean(user_value_noise_pm1);

PM_platform