ydata=zeros();
ydata = x;
x0=data_u(serial_it);
figure('color',[1 1 1]);
bar(x0,ydata)%*user_number)
%bar(x0,ydata)
xlabel('Value');
ylabel('Frequency distribution histogram');


