m_step = 10;  
x_record=zeros();
L_record=zeros();
d=number_d2;
%n=data_u_map;
 n=data_u_map;
x=zeros(d,1)+1/d;
P=zeros();
M=M0;
for iteration = 1:m_step
        for i=1:d
            temp0=0;
            for j=1:db1 
                mxk=sum(M(j,1:d)*x);  %���û�취��
                temp0=temp0+n(j)*M(j,i)/(mxk);
            end
             P(i)=x(i)*temp0;
        end
    %��ߵ������Ȼ����ô��� 
    %M 
      temp1=sum(P);
     for i=1:d
           temp2=P(i)/temp1;
            x(i)=temp2;
             x_record(iteration,i)=x(i);
     end
     
     %M-step
       x=P/sum(P);
       x=x';
end
x_em=x;
 %��û�о���ͳһ������
 %distribution_EM
