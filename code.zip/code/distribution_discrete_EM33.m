ydata=zeros();
ydata2=zeros();
ydata = x(1:d);
ydata2= x(d+1:d+t);
x0=-1:2/(d-1):1;
figure('color',[1 1 1]);
subplot(2,2,1);bar(x0,ydata);
xlabel('Value');
ylabel('Frequency distribution histogram');
x2=0:C/(t-1):C;
subplot(2,2,2);
bar(x2,ydata2);
format short;
ydata_show=[sum(ydata),sum(ydata2)]
%Mean_estimation

