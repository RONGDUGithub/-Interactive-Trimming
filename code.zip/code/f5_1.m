% clear all;
% x=1:1:5;
% gg1=1;



combinefigure2

grid off;
saveas(gcf, 'data5_1.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf