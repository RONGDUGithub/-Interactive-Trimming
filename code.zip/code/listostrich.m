%纳什均衡的结果
clear all;
index=1;
load('data.mat');
%选择数据
%a=data2;
%攻击者比例
%attack_ratio=0.006494;
attack_ratio=0.2;
round_no=10;
x1=0.95;
x2=x1+0.01;
x3=x1-0.03;

pick=8;
round_time=50;
MSE_final=zeros(round_time,2);
nmi_final=zeros(round_time,2);
sumd_final=zeros(round_time,2);

for round=1:round_time
  data_generate

    MD1=[];
    nmi=[];
    sumD=[];
    %方案0
    Ostrich;
    metric_compare;
    MD1=[MD1,scoreori,mean_distance];
    nmi=[nmi,NMI];
    sumD=[sumD,sumDori,sumD2];
    base_ostrich1=Idx1;
    base_ostrich2=Idx2;

    %方案1
    Ostrich2;
    metric_compare;
    MD1=[MD1,mean_distance];
    nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_idx1=Idx1;
    base_idx2=Idx2;


   MD1_final(round,:)=MD1;
   nmi_final(round,:)=nmi;
end

if round_time==1
    % 真质心和假质心的距离，按照4种方案
    a_mean_distance=(MD1_final);
    %nmi的最后指标，按照4种方案
    a_nmi_final=(nmi_final);
else
    % 真质心和假质心的距离，按照4种方案
    a_mean_distance=mean(MD1_final);
    %nmi的最后指标，按照4种方案
    a_nmi_final=mean(nmi_final);
end

sumd_final=sumD;
% RsumD;
bar_figure;
%将结果存储

a_mean_distance
sumD
save test1
load handel
sound(y,Fs)