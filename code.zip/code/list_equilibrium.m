%纳什均衡的结果
clear all;
index=1;
load('data.mat');

control=dlmread('control.txt');
control_label=dlmread('control_label.txt');
A_1=cat(2,control,control_label);

SSE=[];
%选择数据
%rv=data2;
rv=A_1;

%确定肘部法k的结果
elbow_function;
[Idx1,Cori1,sumD1,D1]=kmeans(rv,elbow,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
sumDori=sum(sumD1);
%[Idx2,Cori2,sumD0,D]=kmeans(rv,elbow,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
%sumDori=sum(sumD0);

%实验总轮数
round_time=100;
attack_ratio=0.4;
%单次实验的数据收集轮数
round_no=10;
x1=0.95;
% x1=1;
x2=x1+0.01;
x3=x1-0.03;

%MSE_final=zeros(round_time,5);

sumd_final=zeros(round_time,5);


for roundo=1:round_time
  data_generate
   MD1=[];
%   nmi=[];
    sumD=[];
    %方案0
    Ostrich;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_ostrich1=Idx1;
    base_ostrich2=Idx2;


    %方案1
    baseline;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_idx1=Idx1;
    base_idx2=Idx2;

        %方案1
    baseline2;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_idx1=Idx1;
    base_idx2=Idx2;

    %方案2
    tit_for_tat;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
   sumD=[sumD,sumD2];
    base_tit_for_tat_idx1=Idx1;
    base_tit_for_tat_idx2=Idx2;


%方案3
    k=0.1;
    elastic;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_elastic1_idx1=Idx1;
    base_elastic1_idx2=Idx2;
AElastic1=report_vector;

    %方案4
    k=0.5;
    elastic;
    metric_compare;
    MD1=[MD1,mean_distance];
    %nmi=[nmi,NMI];
    sumD=[sumD,sumD2];
    base_elastic2_idx1=Idx1;
    base_elastic2_idx2=Idx2;
AElastic5=report_vector;

   MD1_final(roundo,:)=MD1;
   %nmi_final(roundo,:)=nmi;
end

if round_time==1
    % 真质心和假质心的距离，按照4种方案
    a_mean_distance=(MD1_final);
    %nmi的最后指标，按照4种方案
    %a_nmi_final=(nmi_final);
else
    % 真质心和假质心的距离，按照4种方案
    a_mean_distance=mean(MD1_final);
    %nmi的最后指标，按照4种方案
    %a_nmi_final=mean(nmi_final);
end

sumd_final=mean(sumD);
%RsumD;
bar_figure;
%将结果存储

%num_same = [numel(intersect(A_Ostrich,A_1)) numel(intersect(A_Baseline_09,A_1)) numel(intersect(A_Baseline_static,A_1)) numel(intersect(A_Titfortat,A_1)) numel(intersect(AElastic1,A_1)) numel(intersect(AElastic5,A_1))]
%num_same_rows = [sum(ismember(A_1, A_Ostrich, 'rows')) sum(ismember(A_1, A_Baseline_09, 'rows')) sum(ismember(A_1, A_Baseline_static, 'rows')) sum(ismember(A_1, A_Titfortat, 'rows')) sum(ismember(A_1, AElastic1, 'rows')) sum(ismember(A_1, AElastic5, 'rows'))]

a_mean_distance
%mean_distance1=compare_cluster_centers_dist(Cori1,Cori2)
%sumD
save test1
load handel
sound(y,Fs)
