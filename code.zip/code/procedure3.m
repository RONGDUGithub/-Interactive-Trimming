% ia=1;
% p_trim=0.95;
% ai=0.99;
part_index=[];
lefti=1+(ia-1)*La_round;
righti=ia*La_round;
normal_data=b1(lefti:righti,:);
normal_index=all_index(lefti:righti);
part_index=[part_index;normal_index];

lefta=1+(ia-1)*attack_number_round;
righta=ia*attack_number_round;
attack_data=attacke_default_matrix(lefta:righta,:);
attack_no=righta-lefta+1;
attack_index=zeros(attack_no,1)-1;
part_index=[part_index;attack_index];

normal_pick_line = normal_data(:, pick);
value_attack = quantile(normal_pick_line, ai);

%找出p_trim位置的大小
value_attack_vector=zeros(attack_number_round,1)+value_attack;
attack_data(:,pick)=value_attack_vector;

%综合数据
collect_data=[normal_data;attack_data];
%collect_data_copy=[collect_data_copy,part_index];
sortedA = sortrows(collect_data, pick);

collect_data_copy=[collect_data,part_index];
sortedA_copy=sortrows(collect_data_copy, pick);
% 
% %Trim的结果
% trimming_result=sortedA(1:floor(p_trim*La_round),:);
% trimming_result_copy=sortedA_copy(1:floor(p_trim*La_round),:);
%   
report_vector = [report_vector;collect_data];
report_vector_copy=[report_vector_copy; sortedA_copy];

% size(report_vector)
% gaga=ia
