function mean_EM=mean_PM1(collect_data,t,d_pm,x,db1,C,data_u_map,group_number,attacker_number)
% mean_PM1(collect_data,t_pm,number_d2,x_remfII,db1,C,data_u_map,group_number,attacker_number);
ydata2=zeros();
ydata2= x(d_pm+1:d_pm+t);
sum0=sum(collect_data);
interval=2*C/db1;
sum1=0;
ad3=zeros();
ad3(1)=-1*C;
for g=2:1:db1+1
    ad3(g)=ad3(g-1)+interval;
end
%要写攻击者的攻击数据统计
oni=db1-t+1;
for i=1:1:floor(t)
   temp0= oni+i;
  ni= ydata2 (i);
  %这里应该很准才对呀,这个数据可能是反着的
  f=1/2*(ad3(temp0-1)+ad3(temp0));
  sum1=sum1+ni*f*(group_number+attacker_number);
end
%这里没啥问题
mean_EM=(sum0-sum1)/((1-sum(ydata2))*(group_number+attacker_number)); 
end