function sc = kmeans_silhouette(X, k)
% 计算 k-means 聚类结果轮廓系数
% 输入参数：
%   - X: (m x n) 的数据矩阵，其中 m 表示数据样本数，n 表示特征数
%   - k: 聚类簇的个数
% 输出参数：
%   - sc: 聚类结果的轮廓系数

% 运行 k-means 算法
[~, C] = kmeans(X, k);

% 计算每个样本点的簇标签
idx = kmeans(X, k, 'MaxIter', 1000, 'Replicates', 10, 'Start', C);

% 计算每个样本点与其他同簇样本点的平均距离 a(i)
a = zeros(size(X, 1), 1);
for i = 1:k
    idx_i = (idx == i);
    if sum(idx_i) == 0
        continue
    end
    a(idx_i) = pdist2(X(idx_i, :), X(idx_i, :), 'euclidean');
    a(idx_i) = sum(a(idx_i, :), 2) ./ (sum(idx_i) - 1);
end

% 计算每个样本点与其他不同簇样本点的最小平均距离 b(i)
b = zeros(size(X, 1), 1);
for i = 1:k
    idx_i = (idx == i);
    if sum(idx_i) == 0
        continue
    end
    b(idx_i) = pdist2(X(idx_i, :), C(setdiff(1:k, i), :), 'euclidean');
    b(idx_i) = min(b(idx_i, :), [], 2);
end

% 计算轮廓系数
s = (b - a) ./ max(a, b);
sc = mean(s);
end