figure
subplot(2, 1, 1) % 将画布分成2行1列，在第1个子区域内绘制图形
bar((a_mean_distance));
max_al=max(a_mean_distance);
min_al=min((a_mean_distance));
%delta1=1000;
%ylim([min_al-delta1,max_al+delta1]);
% 设置纵轴刻度的显示格式
%ytickformat('%.2f');

% 禁用科学计数法
%set(gca, 'YTickLabel', get(gca, 'YTick'));


%set(gca, 'YScale', 'log')

xticklabels({'Ostrich', 'Baseline_{0.9}', 'Baseline_{static}' , 'Titfortat', 'Elastic_{0.1}', 'Elastic_{0.5}'});
title('Distance')

subplot(2, 1, 2) % 将画布分成2行1列，在第2个子区域内绘制图形

plot(sumd_final)

set(gca, 'YScale', 'log')

xticklabels({'Ostrich', 'Baseline_{0.9}', 'Baseline_{static}' , 'Titfortat', 'Elastic_{0.1}', 'Elastic_{0.5}'});
title('Distance')
title('SSE')

 set(gcf, 'PaperPosition', [0.25 0 13.5 10]);
 set(gcf, 'PaperSize', [13 10]); %Ke5p the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
grid off;

%改图名字

