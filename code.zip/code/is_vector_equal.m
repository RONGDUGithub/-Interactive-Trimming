function is_same = is_vector_equal(u, v)
% 判断两个向量是否一致
% u: 第一个向量
% v: 第二个向量
% is_same: 返回值，布尔类型，表示两个向量是否一致

% 确保 u 和 v 的长度相等
if length(u) ~= length(v)
    is_same = 0;
    return
end

% 逐个比较 u 和 v 的每个元素
for i = 1:length(u)
    if u(i) ~= v(i)
        is_same = 0;
        return
    end
end

is_same = 1;
end