Main_pmcalibration
mean_PM_sum
m_step=50;
x_emf=EMF(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,C);

mean_x_emf=mean_PM1(A_collect,t_pm,number_d2,x_emf,db1,C,data_u_map,length(b),attack_number);
