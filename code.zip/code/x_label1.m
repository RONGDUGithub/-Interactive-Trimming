x=attack_ratio_vector;
% 设置x轴标签
xt = x;
xtl = cell(size(xt));
xtl{1} = num2str(x(1));
for i = 2:length(xt)
    xtl{i} = num2str(xt(i));
end
set(gca,'XTickLabel',xtl)