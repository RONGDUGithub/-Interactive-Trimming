clear all;

% 定义参数p的范围和间隔
p_range = 0:0.1:1;

% 定义存储结果的数组
Count_Terminate_Round = zeros(1, length(p_range));
final_ratio_gang = zeros(1, length(p_range));
final_ratio_elastic = zeros(1, length(p_range));

% 遍历参数p的取值范围
for i = 1:length(p_range)
    p = p_range(i);
    
    % 执行给定的代码
    index=1;
    control=dlmread('control.txt');
    control_label=dlmread('control_label.txt');
    A_1=cat(2,control,control_label);
    SSE=[];
    rv=A_1;
    elbow_function;
    [Idx1,Cori1,sumD1,D1]=kmeans(rv,elbow,'dist','sqEuclidean','rep',10, 'MaxIter', 200);
    sumDori=sum(sumD1);
    trim_switch=1;
    a=rv;
    attack_ratio=0.2;
    round_no=25;
    data_generate
    elbow=10;
    round_time=10;
    final_attack_rati0_gang=zeros(1,round_time);
    final_attack_ratio_elastic=zeros(1,round_time);
    for round=1:round_time
        baseline_evade_gang;
        H=size(report_vector_copy);
        h1=H(1);  
        final_attack_rati0_gang(1,round)=length(find(report_vector_copy_gang(:,end)==-1))/h1;
        baseline_evade_elastic;
        H=size(report_vector_copy);
        h1=H(1);  
        final_attack_rati0_elastic(1,round)=length(find(report_vector_copy_elastic(:,end)==-1))/h1;
    end
    final_ratio_gang(i) = mean(final_attack_rati0_gang);
    final_ratio_elastic(i) = mean(final_attack_rati0_elastic);
    Count_Terminate_Round(i) = count_terminate_round;
    
    % 将结果存储
    save(['test_p_', num2str(p)], 'final_ratio_gang', 'final_ratio_elastic', 'Count_Terminate_Round');
end

% 将结果转换为表格
T = table(p_range', Count_Terminate_Round', final_ratio_gang', final_ratio_elastic', 'VariableNames', {'p', 'count_terminate_round', 'final_ratio_gang', 'final_ratio_elastic'});

% 显示表格
disp(T);

% 绘制三个结果与p的关系图
figure;
hold on;
plot(p_range, final_ratio_gang, 'o-', 'DisplayName', 'final_ratio_gang');
plot(p_range, final_ratio_elastic, 's-', 'DisplayName', 'final_ratio_elastic');
plot(p_range, Count_Terminate_Round, '^-', 'DisplayName', 'count_terminate_round');
xlabel('p');
legend('show');
grid on;