temp0=rand(attacker_number,1);
temp1=1*(temp0-min(temp0))/(max(temp0)-min(temp0));

r0 = b11 + (a11-b11).*temp1 ;
attacker_data_new=round(r0);

%attacker_data_new=zeros(attacker_number,1)+C;
collect_data_sw=[user_value_noise_sw;attacker_data_new];
%统计个数  1：db各自的数目
%collect_data=collect_data_sw;
mean_sort=sort(collect_data_sw);
knowledge=0.5;
 
 %应该用SW的数据
interval=1/(d_sw);
a_td2=zeros();
a_td2(1)=0;
for i=2:1:db_sw+1
a_td2(i)=a_td2(i-1)+interval; 
end
 

%这个地方过于小了，要重新算
collect_data_mini50=mean_sort(1:(knowledge*length(collect_data_sw)));
%%%%%%%%%%%%%%%%%%%这里要重新写
n_0=zeros(d_sw,1);
for j=1:db_sw
  %tempp2=length(find(collect_data_mini50>=a_td2(j)& collect_data_mini50<a_td2(j+1)));
   n_0(j)=length(find(collect_data_mini50==j));
end 
xao=EM_SW(collect_data_mini50,d_sw,db_sw,m_step,M,n_0);

interval=1/(d_sw);    
td1=1/2*interval;
a_td1=zeros();

a_td1(1)=td1;
for i=2:1:d_sw
a_td1(i)=a_td1(i-1)+interval; 
end

%x的和是1也没啥问题
O_pie_sw=sum(xao.*a_td1');

t_sw=ceil((db_sw)*(1+b_value-O_pie_sw)/(2*b_value+1));

%%%%%%%%%%%%%%%%%%%这里要重新统计数据
 n_sw=zeros(db_sw,1);
 for qi=1:db_sw
   %  n_sw(qi)=length(find(collect_data>=a_td2(qi)& collect_data<a_td2(qi+1)));
    n_sw(qi)=length(find(collect_data_sw==qi));
 end
 hello=1
 

 
 