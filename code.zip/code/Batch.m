%figure_legend
% 指定数据集和标签文件的名称和路径
%data_names = {'control', 'ionosphere', 'letter', 'vehicl', 'wine'};
%data_paths = {'dataset/control.txt', 'dataset/ionosphere.txt', 'dataset/letter.txt', 'dataset/vehicle.txt', 'dataset/wine.txt'};
data_names = {'vehicl', 'wine'};
data_paths = {'dataset/vehicl.txt', 'dataset/wine.txt'};
label_paths = {'dataset/control_label.txt', 'dataset/ionosphere_label.txt', 'dataset/letter_label.txt', 'dataset/vehicl_label.txt', 'dataset/wine_label.txt'};

% 指定要改变的参数的取值范围
x1_range = [0.9, 0.95, 0.97];

% 指定攻击比例的取值范围
attack_ratio_range = {[0, 0.01], [0.05, 0.15], [0.2, 0.5]};

% 循环处理每个数据集
for k0 = 1:numel(data_names)
    % 读取数据集和标签文件
    data_path = data_paths{k0};
    label_path = label_paths{k0};
    data = dlmread(data_path);
    label = dlmread(label_path);
    
    % 循环处理每个参数组合
    for i0 = 1:numel(x1_range)
        for j0 = 1:numel(attack_ratio_range)
            % 调整参数
            x1 = x1_range(i0);
            attack_ratio_vector = linspace(attack_ratio_range{j0}(1), attack_ratio_range{j0}(2), 6);

            % 进行实验
            All_distance = zeros(length(attack_ratio_vector), 6);
            All_sse = zeros(length(attack_ratio_vector), 6);
            for qj = 1:length(attack_ratio_vector)
                % 要改变的参数
                attack_ratio = attack_ratio_vector(qj);

                % 进行实验并收集结果
%                trimmed_data = trim_data(data, label, x1);
%                [a_mean_distance, sumd_final] = kmeans_with_adversarial(trimmed_data, label, attack_ratio);
figure_group2;                
All_distance(qj,:) = a_mean_distance;
                All_sse(qj,:) = sumd_final;

                % 绘制图像并保存为 PDF 文件
                
%                 figure_name = sprintf('%s_x1_%.2f_attack_ratio_%.2f.pdf', data_names{k0}, x1, attack_ratio);
%                 figure_path = fullfile('figures', figure_name);
%                 saveas(gcf, figure_path, 'pdf');

            % 绘制图像并保存为 PDF 文件
            combinefigure2;
            figure_name = sprintf('%s_x1_%.2f_attack_ratio_range_%.2f_%.2f.pdf', data_names{k0}, x1, attack_ratio_range{j0}(1), attack_ratio_range{j0}(2));
            figure_path = fullfile('figures', figure_name);
            saveas(gcf, figure_path, 'pdf');
cla;

        end
    end
    end
end