function x_remf_sw=REMF_SW(d_sw,db_sw,t_sw,M,m_step,n_sw,ratio)
db=db_sw;
  t1=t_sw;
  M2=eye(db);
 M4=M2(:,db-t1+1:db);
M3=[M,M4];
M=M3;
n=n_sw;
x_record=zeros();
L_record=zeros();
%n��ʲô�������
%���ж�Ӧ��λ�õ���Ŀ����

x=zeros(d_sw+t1,1)+1/(d_sw+t1);
P=zeros(d_sw+t1,1);

for iteration = 1:m_step
    %E
        parfor i=1:d_sw+t1
            temp0=0;
            for j=1:db 
                   mxk=0;
                mxk=sum(M(j,1:d_sw+t1)*x);  %���û�취��
                temp0=temp0+n(j)*M(j,i)/(mxk);
            end
             P(i)=x(i)*temp0;
        end
    %��ߵ������Ȼ����ô��� 
    %M 
           temp2(1:d_sw)=P(1:d_sw)/sum(P(1:d_sw));
            x(1:d_sw)=temp2(1:d_sw)*(1-ratio);
           
           temp2(d_sw+1:d_sw+t1)=P(d_sw+1:d_sw+t1)/sum(P(d_sw+1:d_sw+t1));
            x(d_sw+1:d_sw+t1)=temp2(d_sw+1:d_sw+t1)*ratio;
end
x_remf_sw=x;
distribution_discrete_EM33_SW
% mean_estimation_SW
% at_remf_sw=meanll;
end

