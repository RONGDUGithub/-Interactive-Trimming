db1=10000;
format rat
%首先将数据离散化
%db=floor(power(user_number,1/2));
%d=user_number/100;
%umax=max(user_value_noise_pm);%实际上这步不对，还是从PM机制里直接拿出来比较合适
C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
umin1=((C+1)*(-1))/2-(C-1)/2;
umax1=umin1+C-1;
umin2=((C+1)*1)/2-(C-1)/2;
umax2=umin2+C-1;


%离散后的数值应该是什么
uinterval=(umax2-umin1)/db1;
u_original=umin1+1/2*uinterval; 
data_u=zeros(db1,1);
for i=1:db1
    data_u(i)=u_original+(i-1)*uinterval;
end

%每个数据对应出现的次数
 %data_u_map=hist(collect_data,db1);
data_u_map=hist(user_value_noise_pm,db1);
data_u_map1=data_u_map;
%找到原始数据的位置
 it_loc_minus1=item_location(-1,data_u,db1);
  it_loc_posi1=item_location(1,data_u,db1);
  
  it_loc1=item_location(1,data_u,db1);
  it_loc2=item_location(C,data_u,db1);
  
serial_it=it_loc_minus1:1:it_loc_posi1;
number_d2=it_loc_posi1-it_loc_minus1+1;
number_d=it_loc2-it_loc1+1;



%找个b
M0=Mmatrix_PM(epsilon,db1,number_d,serial_it,C,data_u,number_d2);
%看起来M矩阵没啥问题 
%然后EM
