%x1=95% x3=50% & x2=99%
%x1=95% x3=60% & x2=97%

%p_trim=0.95
% trim_switch=1;
report_vector=[];
report_vector_copy = [];
b1_copy=[b1,tempH];
%data collector trim的位置
p_trim = x2;
%p_trim=1;
%攻击者攻击的位置
ai=x3;
for ia=1:round_no
    if index==1
        procedure2
    else
        if index==2
            procedure4
        end
    end
end

A_Titfortat=report_vector;

% rng('shuffle');
% rv1=report_vector;
% n = size(rv1, 1);
% idx = randperm(n);
% report_vector = rv1(idx, :);