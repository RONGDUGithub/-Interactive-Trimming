function score = silhouette_score(X, labels)
% 计算轮廓系数
% X: 数据矩阵，每行为一个样本
% labels: 每个样本的簇标签
% score: 轮廓系数
n_samples = size(X, 1);
cluster_labels = unique(labels);
n_clusters = length(cluster_labels);
if n_clusters == 1
    score = 0;
    return;
end
a = zeros(n_samples, 1);
b = zeros(n_samples, 1);
s = zeros(n_samples, 1);
for i = 1:n_samples
    label = labels(i);
    cluster_i = X(labels == label, :);
    a_i = mean(sqrt(sum((cluster_i - X(i, :)).^2, 2)));
    a(i) = a_i;
    for j = 1:n_clusters
        if j ~= label
            cluster_j = X(labels == cluster_labels(j), :);
            b_ij = mean(sqrt(sum((cluster_j - X(i, :)).^2, 2)));
            if j == 1
                b(i) = b_ij;
            elseif b_ij < b(i)
                b(i) = b_ij;
            end
        end
    end
    s(i) = (b(i) - a(i)) / max(a(i), b(i));
end
score = mean(s);
end