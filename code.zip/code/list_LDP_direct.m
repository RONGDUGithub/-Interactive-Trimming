%2	1	0.5	0.25	0.125	0.0625
clear all;

load('data_taxi.mat')
index=1;
epsilon=2;
attack_ratio=0.2;
round_no=20;
data_generate_direct

round_time=1;
%cluster_number=4;
x1=0.95;
x2=x1+0.01;
x3=x1-0.03;

mean_final=zeros(round_time,6);
for round=1:round_time
    MD1=[];
    %方案0
    Ostrich;
    mean_sta;
    MD1=[MD1,meann];

    %方案1
    baseline;
    mean_sta;
    MD1=[MD1,meann];

    %方案2
    tit_for_tat;
    mean_sta;
    MD1=[MD1,meann];

    %方案3
    k=0.1;
    elastic;
    mean_sta;
    MD1=[MD1,meann];

    %方案4
    k=0.5;
    elastic;
    mean_sta;
    MD1=[MD1,meann];

    %方案5 DAP
    data_generate3;
    MD1=[MD1,mean_x_emf];
    %总计
    MD1_final(round,:)=MD1;
end
if round_time==1
% 真质心和假质心的距离，按照4种方案
a_mean_distance=(MD1_final);
else
% 真质心和假质心的距离，按照4种方案
a_mean_distance=mean(MD1_final);
end
a_mean_final_square=power(a_mean_distance-mean_groundtruth,2);

bar(a_mean_final_square);
xticklabels({'Ostrich', 'baseline', 'titfortat', 'elastic1', 'elastic2','EMF'});