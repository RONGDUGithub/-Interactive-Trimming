function it_loc=item_location(item,data_u,db)
it_loc=find(data_u > item, 1, 'first');

if it_loc==1
   it_loc=1;
else
temp=(data_u(it_loc)+data_u(it_loc-1))/2;
if temp>item
    it_loc=it_loc-1;
else
    it_loc=it_loc;
end
end
if item>data_u(db)
    it_loc=db;
end
end