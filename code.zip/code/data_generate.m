rng('shuffle');

n = size(rv, 1);
idx = randperm(n);
a = rv(idx, :);

max_a=max(a);
min_a=min(a);

delta_a=max_a-min(a);
[max_delta_a,location]=max(delta_a);

%选择加毒的属性和位置
pick=location;

size_a=size(a);
size_a2=size_a(2);
La=length(a);
% random_sequence = randperm(La);
% b=a(random_sequence,:);
b=a;

attack_number=attack_ratio*length(a);

%实验的轮数

attack_number_round=ceil(attack_number/round_no);
attack_number_all=attack_number_round*round_no;

La0=La-attack_number_all;
La1=La0-mod(La,round_no);
La_round=La1/round_no;

b1=b(1:La1,:);
ground_truth_vector=b1;
temp=1:La1;
tempH=temp';
all_index=tempH;
b1_copy=[b1,tempH];


b_attack=b(La1+1:La1+attack_number_all,:);
attacke_default_matrix =b_attack;
%这里是一个随机数据的生成
%random_matrix = rand(attack_number_all, size_a2);
%attacke_default_matrix = bsxfun(@plus, bsxfun(@times, random_matrix, (max_vec - min_vec)), min_vec);



%[db_index, elbow] = db_index(a, 10)

%scoreori = silhouette_score(a, Idx1);