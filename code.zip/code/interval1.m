function hmk=interval1(user_value_noise_pm1,db,C)
interval0=(2*C)/db;
%tk[0]=-C;
tk=zeros();
for jkl=1:1:db
   tk(jkl)=-C+jkl*interval0;
end
hmk=zeros();
hmk(1)=length(user_value_noise_pm1(find(user_value_noise_pm1>=-C&user_value_noise_pm1<=tk(1))));
for jkl=1:1:db-1
  hmk(jkl+1)=length(user_value_noise_pm1(find(user_value_noise_pm1>tk(jkl)&user_value_noise_pm1<=tk(jkl+1))));
end
end