function ARI = calculate_ARI(G1, G2)
    % 计算混淆矩阵
    C = confusionmat(G1, G2);

    n = sum(C(:));  % 计算所有样本的数量

    % 计算混淆矩阵中所有元素的组合数之和
    comb_C = arrayfun(@(x) nchoosek(x, 2), C(C >= 2));
    sum_comb = sum([0; comb_C(:)]);

    % 计算每行组合数之和
    row_sums = sum(C, 2);
    comb_row = arrayfun(@(x) nchoosek(x, 2), row_sums(row_sums >= 2));
    sum_row_comb = sum([0; comb_row(:)]);

    % 计算每列组合数之和
    col_sums = sum(C, 1);
    comb_col = arrayfun(@(x) nchoosek(x, 2), col_sums(col_sums >= 2));
    sum_col_comb = sum([0; comb_col(:)]);

    % 计算Index, Expected_index, Max_index
    index = sum_comb;
    expected_index = sum_row_comb * sum_col_comb / nchoosek(n, 2);
    max_index = (sum_row_comb + sum_col_comb) / 2;

    % 计算ARI
    ARI = (index - expected_index) / (max_index - expected_index);
end
