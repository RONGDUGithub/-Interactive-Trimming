%trim的位置
p=0.8;
delta=0.05;
x2 = 0.95;
x3 = 0.9;
report_vector = [];
report_vector_copy = [];
b1_copy=[b1,tempH];
%攻击者进攻的位置，这里只是一个起始为主
ai=1;
count=1;
for ia=1:round_no
    
   
     r = rand();    
     if r<p
     ai=x2; 
     else
     ai=x3; 
     end
 

end

metric_compare







