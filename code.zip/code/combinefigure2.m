y_pp=All_distance;

y_P=All_sse;

B= jet(300);
C=jet(300);
% C=[1,1,1];
 


subplot(2,1,1) % 2行1列，第1个子区域
h=bar(y_pp);
 set(h(1),'FaceColor',C(250, :));
set(h(2),'FaceColor',C(50, :));
set(h(3),'FaceColor',C(150, :)); 
set(h(4),'FaceColor',C(200, :));
set(h(5),'FaceColor',C(100, :));
set(h(6),'FaceColor',C(300, :));


%xlabel(' \epsilon');
xlabel(' attack_{ratio}');
set(gca,'xticklabel',[]);%不显示x坐标轴刻度
set(gca,'box','on');
 set(gca,'FontWeight','bold','FontSize',15);
ylabel('Distance','interpreter','latex');
x_label1;
% g1=max(max(y_pp));
% g2=min(min(y_pp));
% ylim([g2-0.05,g1+g1-g2])
%ax = gca;
%ax.YColor = 'k';

subplot(2,1,2) % 2行1列，第2个子区域
x=1:1:length(attack_ratio_vector);
plot(x,y_P(:,1),'-*','MarkerSize',12,'LineWidth',2.6,'Color',C(250, :));
hold on;
plot(x,y_P(:,2),'-o', 'MarkerSize',12,'LineWidth',2.6,'Color',C(50, :));
plot(x,y_P(:,3),'-s', 'MarkerSize',12,'LineWidth',2.6,'Color',C(150, :));
plot(x,y_P(:,4),'-^', 'MarkerSize',12,'LineWidth',2.6,'Color',C(100, :));
 plot(x,y_P(:,5),'-x','MarkerSize',12,'LineWidth',2.6);
plot(x,y_P(:,6),'-^', 'MarkerSize',12,'LineWidth',2.6,'Color',C(300, :));

 
%  set(gca,'YScale','log')
% set(gca,'FontWeight','bold','FontSize',15);
xlabel(' attack_{ratio}');
%set(gca,'box','on');
ylabel('SSE','interpreter','latex');
%ylim([-0.4 0.8])
% t1=max(max(y_P));
% t2=min(min(y_P));
% tt1=1.5*t1;
% tt2=t2/(t1/t2)/5;
% ylim([tt2 tt1])
ax = gca;
ax.YColor = 'k';
 set(gca,'FontWeight','bold','FontSize',15);

%set(gca,'FontWeight','bold','FontSize',25);
%set(gca,'XTicklabel',{'0.1','0.2','0.3','0.4','0.5'})
x_label1;
set(gcf, 'PaperPosition', [0.1 0 17.7 13.5]);%设置图的位置，-0.75，0.2表示图片左下角的坐标（pdf页面左下角为（0，0）），26.5，26表示图片的宽高
set(gcf, 'PaperSize', [18 13]); %Keep the same paper size，设置pdf纸张的大小，分别表示pdf页面的长宽?
grid off;
