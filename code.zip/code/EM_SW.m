function x_em_sw=EM_SW(collect_data,d_sw,db1,m_step,M,n)
x_record=zeros();
L_record=zeros();
%n(db1-250:db1)=n(db1-250:db1)+10000;
%d_sw=number_d2;
%n=data_u_map;
%collect_data=collect_data_mini50;
%��

x=zeros(d_sw,1)+1/d_sw;
P=zeros();

for iteration = 1:m_step
        for i=1:d_sw
            temp0=0;
            for j=1:db1 
                mxk=sum(M(j,1:d_sw)*x);  %���û�취��
                temp0=temp0+n(j)*M(j,i)/(mxk);
            end
             P(i)=x(i)*temp0;
             %P
        end
    %��ߵ������Ȼ����ô��� 
    %M 
      temp1=sum(P);
    for i=1:d_sw
           temp2=P(i)/temp1;
            x(i)=temp2;
             x_record(iteration,i)=x(i);
     end
     
     %M-step
       x=P/sum(P);
       x=x';
end
x_em_sw=x;
end




