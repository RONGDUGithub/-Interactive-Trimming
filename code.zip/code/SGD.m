% Load the data
% data = a';
data=report_vector';

% Assign the first column to the variable 'height' and the second column to 'weight'
height = data(:, 1);
weight = data(:, 2);

% Initialize parameters
theta = zeros(2, 1); % We start with some random theta values
alpha = 0.00001; % Learning rate
iterations = 2000; % Number of iterations

% Add a column of ones to the height data
height = [ones(length(height), 1), height];


% Stochastic Gradient Descent
for iter = 1:iterations
    for i = 1:length(height)
        temp3 = 0;
        temp1 = theta(1) - alpha * (height(i,:)*theta - weight(i))*height(i,1);
        temp2 = theta(2) - alpha * (height(i,:)*theta - weight(i))*height(i,2);
        theta(1) = temp1;
        theta(2) = temp2;
    end
end

% Display the final theta values
theta
test_procedure
