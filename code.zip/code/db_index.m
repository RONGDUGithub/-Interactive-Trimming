function [db_index, cluster_num] = db_index(X, max_k)
% X: 输入数据矩阵，每行代表一个样本，每列代表一个特征
% max_k: 最大聚类数

% 计算距离矩阵
D = pdist(X);

% 初始化DB指数和聚类个数
db_index = zeros(max_k-1, 1);
cluster_num = 2:max_k;

for k = cluster_num
    % 聚类
    idx = kmeans(X, k);
    
    % 计算类内距离平均值
    avg_intra_dist = zeros(k, 1);
    for i = 1:k
        avg_intra_dist(i) = mean(D(idx==i));
    end
    
    % 计算类间距离
    inter_dist = zeros(k);
    for i = 1:k-1
        for j = i+1:k
            inter_dist(i,j) = (avg_intra_dist(i) + avg_intra_dist(j)) / norm(X(idx==i,:)-X(idx==j,:));
            inter_dist(j,i) = inter_dist(i,j);
        end
    end
    
    % 计算DB指数
    db_index(k-1) = sum(max(inter_dist,[],2)) / k;
end

% 找到DB指数最小的聚类个数
[~, idx] = min(db_index);
cluster_num = cluster_num(idx);
db_index = db_index(idx);
end