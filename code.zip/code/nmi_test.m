is_same1 = is_vector_equal(base_ostrich1, base_ostrich2);
is_same2 = is_vector_equal(base_idx1,base_idx2);
is_same3 =  is_vector_equal(base_tit_for_tat_idx1,base_tit_for_tat_idx2);
is_same4 =  is_vector_equal(base_elastic1_idx1,base_elastic1_idx2);
is_same5 = is_vector_equal(base_elastic2_idx1,base_elastic2_idx2);

NMI_ostrich=calculate_ARI(base_ostrich1,base_ostrich2);
NMI_baseline=calculate_ARI(base_idx1,base_idx2);
NMI_titfortat=calculate_ARI(base_tit_for_tat_idx1,base_tit_for_tat_idx2);
NMI_elastic1=calculate_ARI(base_elastic1_idx1,base_elastic1_idx2);
NMI_elastic2=calculate_ARI(base_elastic2_idx1,base_elastic2_idx2);

num_same_elements1 = sum(base_ostrich1 == base_ostrich2);
num_same_elements2 = sum(base_idx1 == base_idx2);
num_same_elements3 = sum(base_tit_for_tat_idx1 == base_tit_for_tat_idx2);
num_same_elements4 = sum(base_elastic1_idx1 == base_elastic1_idx2);
num_same_elements5 = sum(base_elastic2_idx1 == base_elastic2_idx2);

num_same=[num_same_elements1,num_same_elements2,num_same_elements3,num_same_elements4,num_same_elements5]
is_same_vector=[is_same1,is_same2,is_same3,is_same4,is_same5]
NMI_result=[NMI_ostrich,NMI_baseline,NMI_titfortat,NMI_elastic1,NMI_elastic2]