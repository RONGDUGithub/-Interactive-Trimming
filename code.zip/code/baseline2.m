trim_switch=1;
p_trim = x1;
%p_trim = 1;
report_vector = [];
report_vector_copy = [];
b1_copy=[b1,tempH];
%攻击者进攻的位置，这里只是一个起始为主
ai=x1-0.01;

count=1;
for ia=1:round_no
%    rng('shuffle')
%    ai = 0.8 + 0.2 * rand();
%ai = 0.1 + 0.9 * rand(1,1);
% if count<attack_number_round
%        [ia, ai];
%       ai=1-1/round_no*(ia-1); 
% end
     if index==1
        procedure2
    else
        if index==2
            procedure4
        end
    end
end
A_Baseline_static=report_vector;

% rng('shuffle');
% rv1=report_vector;
% n = size(rv1, 1);
% idx = randperm(n);
% report_vector = rv1(idx, :);