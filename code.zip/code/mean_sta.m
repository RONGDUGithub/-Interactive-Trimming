meann=mean(report_vector);
gaga=1;