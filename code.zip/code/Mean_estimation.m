sum0=sum(collect_data);
sum1=0;
sum00=0;
%data_u_map
for i=1:1:db1
f1=-C+(i-1)*(2*C)/(db1);
f2=-C+(i)*(2*C)/(db1);
f=(f1+f2)/2;
sum00=sum00+data_u_map(i)/(sum(n))*f*(group_number+attacker_number) ;    
end
%sum0 is similar to sum00


%找到对应的数据
for i=1:1:floor(t)
    f1=(i-1)*C/(t);  
    f2=(i)*C/(t);
    f=(f1+f2)/2 ;
    sum1=sum1+ydata2(i)*f*(group_number+attacker_number) ;
end

 mean_user_value=mean(user_value);
 mean_PM=mean(user_value_noise_pm1);

 
sumga=0;
for i=1:1:d
    f1=-1+(i-1)*(2*1)/(d);
    f2=-1+(i)*(2*1)/(d);
    f=(f1+f2)/2;
    sumga=sumga+ydata(i)*f*(group_number+attacker_number) ;
end
%这个mean_qian就是mean_quan
mean_qian=sumga/(sum(ydata)*(group_number+attacker_number));
mean_EM=(sum0-sum1)/((1-sum(ydata2))*(group_number+attacker_number)); 
%sumga+sum1-sum0
 mean_ostrich=mean(collect_data);
 mean_sort=sort(collect_data);
 knowledge=0.5;
 mean_trimming=mean(mean_sort(1:(knowledge*(group_number+attacker_number))));
 
 %
 mean_sort2=sort(collect_data2);
 mean_trimming2=mean(mean_sort2(1:((1-ratio)*(group_number+attacker_number))))
 meanll=[mean_user_value,mean_PM,mean_EM,mean_qian,mean_ostrich,mean_trimming,mean_trimming2]

 
delta=(sum0-(sum1+sumga))/sum0