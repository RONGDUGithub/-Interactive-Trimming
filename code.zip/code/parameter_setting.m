clear all;
%dataset
control=dlmread('control.txt');

control_label=dlmread('control_label.txt');

%triming_location
x1=0.95;

%attack_ratio

attack_ratio_vector=[0.01,0.05,0.1,0.2,0.3,0.4,0.5];
All_distance=zeros(length(attack_ratio_vector),6);
All_sse=zeros(length(attack_ratio_vector),6);

for qj=1:length(attack_ratio_vector)
%要改变的参数
attack_ratio=attack_ratio_vector(qj);
figure_group1
All_distance(qj,:)=a_mean_distance;
All_sse(qj,:)=sumd_final;
end
combinefigure2

saveas(gcf, 'control1.pdf');%保存命令，即在当前目录下生成名为WithMargin的pdf
