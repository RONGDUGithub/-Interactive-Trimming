function [Hj,HB]=smothing(number_d2,t_pm,x,C)
d=number_d2;
t=t_pm;
ydata2= x(d+1:d+t); %这个范围是对的吗  
ydata3=ydata2;
h=size(ydata3);
h1=h(1);
for i=2:h1-1
         ydata3(i)=1/2*ydata3(i)+1/4*(ydata3(i-1)+ydata3(i+1));  %首位点和最后点的处理是啥
end
x2=0:C/(t-1):C;
%bar(x2,ydata3);
ty=1:1:h1;
[ah,pos]=sort(ydata3);%左侧的a1是排列之后的，pos是排序后的下标
HB=find(ydata3<0.5*sum(ydata3)/t);  
x_t=zeros(h1,1)+1;
x_t(HB)=0;
Hj=sum(x_t);
end