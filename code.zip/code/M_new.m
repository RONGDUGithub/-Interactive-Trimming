%做一个KRR的扰动
kk=size(M0);
kk2=kk(2);
ep=20;
p=exp(ep)/(exp(ep)+db1-1);
q=1/(exp(ep)+db1-1);
Ma=zeros(db1)+q;
Mb=eye(db1)*(p-q);
MQ=Ma+Mb;
item_all=zeros();

for kl=1:1:user_number+attacker_number
    item_all(kl)=item_location((collect_data(kl)),data_u,db1);
end

item_all_2=zeros();
randty=round(rand(1,user_number+attacker_number)*(db1-1)+1);
parfor k2=1:1:user_number+attacker_number
    ap=rand(1);
    if ap<=p
         item_all_2(k2)=item_all(k2);
    else
        item_all_2(k2)=randty(k2);
    end
end
ny=hist(item_all_2,db1);

bar(ny);

P=zeros(db1,kk2);
parfor i=1:kk2
   for j=1:db1
       for k=1:db1
           P(k,i)=P(k,i)+(M0(j,i)*MQ(k,j));
       end
   end
end

EM5

