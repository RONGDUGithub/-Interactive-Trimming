function pmvalue=pmmechnism(user_value,epsilon,user_number)

C=(exp(epsilon/2)+1)/(exp(epsilon/2)-1);
l=((C+1)*user_value)/2-(C-1)/2;
r=l+C-1;
n=0;
pmvalue=zeros(user_number,1);
for i=1:user_number
 n=n+1;
x=rand(1);
p=(exp(epsilon/2))/(exp(epsilon/2)+1);
if x<p
    temp0=l(i)+(r(i)-l(i))*rand(1,1);
    pmvalue(i)=temp0;
else
     temp=(l(i)+r(i))/2;
     while(temp>l(i)&temp<r(i)) 
              temp=-C+(C-(-C))*rand(1);
     end
      pmvalue(i)=temp;
end
end
end