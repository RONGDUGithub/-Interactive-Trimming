d=d_sw;
t=t1;
sum0=sum(collect_data);
sum1=0;
sum00=0;
%data_u_map
interval=1/(d_sw);
td1=1/2*interval;
a_td1=zeros();
a_td1(1)=td1;
for i=2:1:d_sw
a_td1(i)=a_td1(i-1)+interval; 
end

Mean_EM=mean(x.*a_td1);
%sum0 is similar to sum00


%原始数据的数值，其原始数据也不一样
 mean_user_value=mean(user_value_sw);
 mean_PM=mean(user_value_noise_pm1);

 
sumga=0;
for i=1:1:d
    f1=-1+(i-1)*(2*1)/(d);
    f2=-1+(i)*(2*1)/(d);
    f=(f1+f2)/2;
    sumga=sumga+ydata(i)*f*(group_number+attacker_number) ;
end
%mean_qian是mean_quan
mean_qian=sumga/(sum(ydata)*(group_number+attacker_number));
%mean_EM=(sum0-sum1)/((1-sum(ydata2))*(group_number+attacker_number)); 
%sumga+sum1-sum0
 mean_ostrich=mean(collect_data);
 mean_sort=sort(collect_data);
 
 knowledge=0.5;
 mean_trimming=mean(mean_sort(1:(knowledge*(group_number+attacker_number))));
 
 %mean_EM 是真实的均值
 
 %trimming2我不想用了
 mean_sort2=sort(collect_data2);
 mean_trimming2=mean(mean_sort2(1:((1-ratio)*(group_number+attacker_number))))
 
 
 
 %mean_trimming 应该是和扰动方式相关的。
 %SW的结果应该是全部重写的
meanll=[mean_user_value,mean_PM,mean_EM,mean_qian,mean_ostrich,mean_trimming,mean_trimming2]

delta=(sum0-(sum1+sumga))/sum0